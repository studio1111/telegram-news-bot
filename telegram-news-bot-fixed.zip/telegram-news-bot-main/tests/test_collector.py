from app.collector import collect_feed


def test_collect_feed_returns_empty_list_when_feed_request_fails(monkeypatch):
    import requests

    def fail(*args, **kwargs):
        raise requests.RequestException("network down")

    monkeypatch.setattr("app.collector.requests.get", fail)

    assert collect_feed("https://example.com/feed", "Example") == []


def test_video_media_content_is_not_used_as_photo():
    from app.collector import _image_url

    entry = {
        "media_content": [
            {"url": "https://example.com/clip.mp4", "medium": "video", "type": "video/mp4"},
            {"url": "https://example.com/pic.jpg", "medium": "image"},
        ]
    }
    assert _image_url(entry) == "https://example.com/pic.jpg"

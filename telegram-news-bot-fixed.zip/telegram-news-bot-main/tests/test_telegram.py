from app.telegram import build_rich_message_payload

def test_rich_message_embeds_photo_and_text_in_one_message():
    payload = build_rich_message_payload(
        "<b>تیتر خبر</b><details><summary>مشاهده متن کامل خبر</summary><p>متن کامل</p></details>",
        "https://example.com/hero.jpg",
    )
    rich = payload["rich_message"]
    assert rich["html"].startswith('<img src="tg://photo?id=hero"/>')
    assert rich["media"] == [
        {
            "id": "hero",
            "media": {"type": "photo", "media": "https://example.com/hero.jpg"},
        }
    ]
    assert "تیتر خبر" in rich["html"]
    assert "متن کامل" in rich["html"]

def test_rich_message_without_image_keeps_text():
    payload = build_rich_message_payload("<b>تیتر خبر</b>", "")
    assert payload["rich_message"]["html"] == "<b>تیتر خبر</b>"
    assert "media" not in payload["rich_message"]


def test_telegram_error_includes_api_description(monkeypatch):
    import pytest
    from app import telegram

    class Resp:
        ok = False
        status_code = 400
        text = "bad"

        def json(self):
            return {"ok": False, "description": "Bad Request: wrong HTTP URL"}

    monkeypatch.setattr(telegram.requests, "post", lambda *a, **k: Resp())
    with pytest.raises(telegram.TelegramError, match="wrong HTTP URL"):
        telegram._post("t", "sendRichMessage", {})


def test_telegram_retries_on_flood_limit(monkeypatch):
    from app import telegram

    calls = {"n": 0}

    class Flood:
        ok = False
        status_code = 429
        text = ""

        def json(self):
            return {"ok": False, "description": "Too Many Requests", "parameters": {"retry_after": 1}}

    class Ok:
        ok = True
        status_code = 200

        def json(self):
            return {"ok": True, "result": {}}

    def fake_post(*a, **k):
        calls["n"] += 1
        return Flood() if calls["n"] == 1 else Ok()

    monkeypatch.setattr(telegram.requests, "post", fake_post)
    monkeypatch.setattr(telegram.time, "sleep", lambda *_: None)
    assert telegram._post("t", "sendRichMessage", {})["ok"] is True
    assert calls["n"] == 2

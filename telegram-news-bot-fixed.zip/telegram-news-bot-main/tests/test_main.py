from datetime import datetime, timezone

from app.collector import NewsItem
import app.main as news_main


def _fake_store():
    class FakeStore:
        last_seen = None
        last_records = None
        saves = 0

        def load(self):
            return set()

        def load_records(self):
            return []

        def save(self, seen, records=None):
            FakeStore.saves += 1
            FakeStore.last_seen = set(seen)
            FakeStore.last_records = list(records or [])

    return FakeStore


_TITLES = {
    1: ("Apple unveils foldable iPhone", "Cupertino shows a hinge design."),
    2: ("Nvidia earnings beat forecasts", "Datacenter revenue surged again."),
    3: ("Lakers win season opener", "Basketball team starts strong."),
}


def _item(n, image="https://example.com/i.jpg"):
    title, summary = _TITLES[n]
    return NewsItem(
        item_id=f"item-{n}",
        title=title,
        url=f"https://example.com/{n}",
        summary=summary,
        source="TechCrunch",
        image_url=image,
        published_at=datetime.now(timezone.utc),
    )


def _patch_common(monkeypatch, store, items):
    monkeypatch.setattr(news_main, "StateStore", store)
    monkeypatch.setattr(news_main.Path, "read_text", lambda *a, **k: '[{"name":"TechCrunch","url":"feed"}]')
    monkeypatch.setattr(news_main, "collect_feed", lambda *a, **k: list(items))
    monkeypatch.setattr(news_main, "is_recent_news", lambda *a, **k: True)
    monkeypatch.setattr(news_main, "fetch_article", lambda *a, **k: ("", ""))


def test_failure_in_one_item_does_not_lose_already_published_state(monkeypatch):
    store = _fake_store()
    _patch_common(monkeypatch, store, [_item(1), _item(2)])
    tech = {"title_fa": "ت", "summary_fa": "خ", "article_fa": "م", "category": "technology"}

    def fake_gemini(title, *a, **k):
        if "Nvidia" in title:
            raise RuntimeError("Gemini down")
        return tech

    sent = []
    monkeypatch.setattr(news_main, "process_with_gemini", fake_gemini)
    monkeypatch.setattr(news_main, "publish_rich_message", lambda *a, **k: sent.append(a))

    news_main.main()

    assert len(sent) == 1
    assert "item-1" in store.last_seen
    assert "item-2" not in store.last_seen


def test_non_technology_item_is_marked_seen_to_save_quota(monkeypatch):
    store = _fake_store()
    _patch_common(monkeypatch, store, [_item(3)])
    monkeypatch.setattr(news_main, "process_with_gemini", lambda *a, **k: {"title_fa": "a", "summary_fa": "b", "category": "sports"})
    monkeypatch.setattr(news_main, "publish_rich_message", lambda *a, **k: (_ for _ in ()).throw(AssertionError))

    news_main.main()

    assert "item-3" in store.last_seen


def test_item_without_image_is_not_marked_seen(monkeypatch):
    class FakeStore:
        last_seen = None

        def __init__(self):
            self.seen = set()
            self.records = []

        def load(self):
            return self.seen

        def load_records(self):
            return self.records

        def save(self, seen, records=None):
            FakeStore.last_seen = set(seen)

    item = NewsItem(
        item_id="item-1",
        title="New technology story",
        url="https://example.com/story",
        summary="A technology story.",
        source="TechCrunch",
        image_url="",
        published_at=datetime.now(timezone.utc),
    )

    monkeypatch.setattr(news_main, "StateStore", FakeStore)
    monkeypatch.setattr(news_main.Path, "read_text", lambda *args, **kwargs: '[{"name":"TechCrunch","url":"feed"}]')
    monkeypatch.setattr(news_main, "collect_feed", lambda *args, **kwargs: [item])
    monkeypatch.setattr(news_main, "is_recent_news", lambda *args, **kwargs: True)
    monkeypatch.setattr(news_main, "fetch_article", lambda *args, **kwargs: ("", ""))

    news_main.main()

    assert FakeStore.last_seen == set()

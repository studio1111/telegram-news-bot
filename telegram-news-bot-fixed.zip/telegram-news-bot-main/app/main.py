import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from .ai import process_with_gemini
from .collector import collect_feed, fetch_article
from .core import (
    build_rich_message_html,
    is_duplicate_story,
    is_new_item,
    is_recent_news,
    is_technology_news,
)
from .storage import StateStore
from .telegram import publish_rich_message

log = logging.getLogger("news-bot")


def _process_item(item, seen, published_stories):
    """Process one feed item. Returns True when it was published."""
    article_text, page_image = fetch_article(item.url)
    image_url = item.image_url or page_image

    # The channel format requires a real source image. Not marked as seen, so
    # it is retried on the next run while still inside the news window.
    if not image_url:
        log.info("skip (no image): %s", item.url)
        return False

    story = {"title": item.title, "summary": item.summary}
    # Cheap check before spending a Gemini call.
    if is_duplicate_story(story, published_stories):
        log.info("skip (duplicate): %s", item.url)
        seen.update((item.item_id, item.url))
        return False

    processed = process_with_gemini(item.title, item.summary, article_text)

    if not is_technology_news(processed.get("category", "")):
        # Classification is final: mark as seen so the same non-tech story is
        # not re-sent to Gemini on every run (wasted quota).
        log.info("skip (category=%s): %s", processed.get("category"), item.url)
        seen.update((item.item_id, item.url))
        return False

    message = build_rich_message_html(
        processed["title_fa"],
        processed["summary_fa"],
        processed.get("article_fa") or processed["summary_fa"],
        item.source,
    )
    publish_rich_message(message, image_url)

    seen.update((item.item_id, item.url))
    published_stories.append(story)
    return True


def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    sources = json.loads(Path("data/sources.json").read_text(encoding="utf-8"))
    store = StateStore()
    seen = store.load()
    published_stories = store.load_records()
    now = datetime.now(timezone.utc)
    failures = 0

    for source in sources:
        try:
            items = collect_feed(source["url"], source["name"], source.get("limit", 100))
        except Exception:
            log.exception("feed failed: %s", source.get("name"))
            failures += 1
            continue

        # Publish oldest first so the channel reads in chronological order.
        items.sort(key=lambda i: i.published_at or now)
        for item in items:
            if not is_new_item(item.item_id, item.url, seen):
                continue
            if not is_recent_news(item.published_at, now):
                continue
            try:
                if _process_item(item, seen, published_stories):
                    # Persist after every post: if a later item crashes the
                    # run, already-published stories must not be re-posted.
                    store.save(seen, published_stories)
            except Exception:
                # One bad item (Gemini/Telegram error) must not abort the run.
                log.exception("item failed: %s", item.url)
                failures += 1

    store.save(seen, published_stories)
    if failures:
        log.warning("%d item(s)/feed(s) failed; they will be retried next run", failures)


if __name__ == "__main__":
    main()

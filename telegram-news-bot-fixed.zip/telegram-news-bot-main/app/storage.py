import json
import os
import tempfile
from pathlib import Path

# Without a cap, "seen" grows forever and every run commits a larger file.
MAX_SEEN = 5000
MAX_RECORDS = 500


class StateStore:
    def __init__(self, path="data/state.json"):
        self.path = Path(path)

    def _read(self):
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def load(self):
        seen = self._read().get("seen", [])
        return set(seen) if isinstance(seen, list) else set()

    def load_records(self):
        records = self._read().get("published_stories", [])
        return records if isinstance(records, list) else []

    def save(self, seen, records=None):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if records is None:
            records = self.load_records()
        # Keep the newest entries: previously-stored order first, then new ones.
        previous = self._read().get("seen", [])
        previous = previous if isinstance(previous, list) else []
        seen = set(seen)
        ordered = [s for s in previous if s in seen]
        known = set(ordered)
        ordered += sorted(s for s in seen if s not in known)
        data = {
            "seen": ordered[-MAX_SEEN:],
            "published_stories": list(records)[-MAX_RECORDS:],
        }
        # Atomic write: a crash mid-write must not corrupt state.json (a
        # corrupt file is read as empty and would re-post everything).
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
            os.replace(tmp, self.path)
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

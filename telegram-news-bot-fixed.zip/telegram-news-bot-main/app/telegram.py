import os
import time

import requests


class TelegramError(RuntimeError):
    pass


def _credentials():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        raise RuntimeError("Telegram credentials are required")
    return token, chat_id


def _post(token, method, payload, attempts=3):
    """Call the Bot API, honouring 429 retry_after and surfacing the real error.

    raise_for_status() alone hides Telegram's `description` (e.g. "wrong file
    identifier/HTTP URL specified"), and a burst of posts to a channel easily
    hits flood limits, so 429 responses are retried after `retry_after`.
    """
    last_error = None
    for attempt in range(attempts):
        try:
            response = requests.post(
                f"https://api.telegram.org/bot{token}/{method}",
                json=payload,
                timeout=30,
            )
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as exc:
            # A timeout may mean the message was actually delivered; do not
            # retry blindly to avoid double posts.
            raise TelegramError(f"Telegram {method} network error: {exc}") from exc

        try:
            data = response.json()
        except ValueError:
            data = {}

        if response.ok and data.get("ok", True):
            return data

        description = data.get("description") or response.text[:500]
        last_error = TelegramError(f"Telegram {method} failed ({response.status_code}): {description}")
        retry_after = (data.get("parameters") or {}).get("retry_after")
        if response.status_code == 429 and attempt < attempts - 1:
            time.sleep(min(int(retry_after or 5), 60))
            continue
        if response.status_code >= 500 and attempt < attempts - 1:
            time.sleep(2 * (attempt + 1))
            continue
        break
    raise last_error


def publish_message(text):
    token, chat_id = _credentials()
    return _post(
        token,
        "sendMessage",
        {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        },
    )


def publish_photo(image_url, caption):
    if not image_url:
        return None
    token, chat_id = _credentials()
    return _post(
        token,
        "sendPhoto",
        {
            "chat_id": chat_id,
            "photo": image_url,
            "caption": caption,
            "parse_mode": "HTML",
        },
    )


def build_rich_message_payload(html, image_url="", chat_id=None):
    rich_message = {
        "html": html,
        "is_rtl": True,
    }

    if image_url:
        # Telegram Rich Messages require media to be declared in the
        # InputRichMessage.media field and referenced from the HTML by tg://.
        rich_message["html"] = f'<img src="tg://photo?id=hero"/>\n\n{html}'
        rich_message["media"] = [
            {
                "id": "hero",
                "media": {
                    "type": "photo",
                    "media": image_url,
                },
            }
        ]

    return {
        "chat_id": chat_id if chat_id is not None else os.environ.get("TELEGRAM_CHAT_ID"),
        "rich_message": rich_message,
    }


def publish_rich_message(html, image_url=""):
    """Publish image, headline, summary and expandable article as one post."""
    token, chat_id = _credentials()
    payload = build_rich_message_payload(html, image_url, chat_id)
    return _post(token, "sendRichMessage", payload)
